
function data          =  UserDefinedInitialData

data.formulation       =  'u';
%str.data.formulation  =  'up';
%data.language         =  'MatLab';
data.language          =  'CMex';

data.analysis          =  'static';