
function ExampleData  =  UserDefinedExampleData


ExampleData.max_load_factor         =  270;    %  Maximum load factor applied on the constant force
ExampleData.N_load_increments       =  3e2;  %  Number of load factors
%ExampleData.loads                  =  [0.03;0.1;0.3;0.6;1;2.6;5;10];
ExampleData.loads                   =  10;
%ExampleData.loads                   =  10;